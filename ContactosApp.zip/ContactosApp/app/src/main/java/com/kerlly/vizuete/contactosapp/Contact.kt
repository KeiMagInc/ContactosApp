package com.kerlly.vizuete.contactosapp

data class Contact(var id:Int=0, var name: String="", var phone: String="", var email: String="")